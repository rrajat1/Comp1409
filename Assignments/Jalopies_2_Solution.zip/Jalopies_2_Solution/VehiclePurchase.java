/**
 * Information Object for a musical instrument rental.
 *
 * @author BullWinkle Moose
 * @version this one
 */

public class VehiclePurchase
{
    private Customer customer;
    private PurchaseDate purchaseDate;
    private Vehicle vehiclePurchased;
    private boolean servicePackage;

    public static final double SERVICE_FEE = 500.00;

    /**
     * @param renter The customer who purchased the vehicle
     * @param purchaseDate The date the Vehicle was purchased
     * @param vehiclePurchased The Vehicle that was purchased
     * @param servicePackage Whether or not the customer opted for the service package.
     */
    public VehiclePurchase(Customer renter, PurchaseDate purchaseDate, Vehicle vehiclePurchased, boolean servicePackage)
    {
        this.customer = renter;
        this.purchaseDate = purchaseDate;
        this.vehiclePurchased = vehiclePurchased;

        this.servicePackage = servicePackage;
    }

    /**
     * @return the customer
     */
    public Customer getCustomer()
    {
        return customer;
    }

    /**
     * @return the purchaseDate
     */
    public PurchaseDate getPurchaseDate()
    {
        return purchaseDate;
    }

    /**
     * @return the vehiclePurchased
     */
    public Vehicle getVehiclePurchased()
    {
        return vehiclePurchased;
    }

    /**
     * @return the servicePackage
     */
    public boolean isServicePackage()
    {
        return servicePackage;
    }

    /**
     * @param servicePackage the servicePackage to set
     */
    public void setServicePackage(boolean servicePackage)
    {
        this.servicePackage = servicePackage;
    }

    /**
     * @param purchasePrice the purchasePrice to set
     */
    public void calculatePurchasePrice(double purchasePrice)
    {
        vehiclePurchased.checkStandardSellingPrice(purchasePrice);

        if(servicePackage)
        {
            vehiclePurchased.setSellingPrice(vehiclePurchased.getSellingPrice() + SERVICE_FEE);
        }
    }

    /**
     * Display the purchase agreement information
     */
    public void displayDetails()
    {
        System.out.println("Customer: " + customer.getFullName());
        System.out.println("Purchase Date: " + purchaseDate.getFullDate());
        System.out.print("Vehicle Description: ");
        vehiclePurchased.printDetails();

        if(servicePackage)
        {
            System.out.println("SERVICE PACKAGE INCLUDED");
        }
    }
}
