
/**
 *  This is first assignment on Person.
 *
 * Paragraph this describes the Person in more details.
 *
 * @author (Rajat)
 * @version (18/01/2019)
 */
 public class Person
  {
    // instance variables - replace the example below with your own
    private int Age;
    private double Height;
    private String FirstName;
    private String LastName;
    
    /**
     * A Basic ctor.
     * 
     * @param _FirstName The First name of the person.
     * @param _LastName  The LastName of the person.
     * @param _Age       The Age of the person.
     * @param _Height    The Height of the person.
     * 
     */
    
    public Person(int _Age, double _Height, String _FirstName, String _LastName)
    {
        //for Age
        if (_Age > 1 && _Age < 100)
        {
        Age = _Age;
        }
        else
        {
            Age = 1;
            System.out.println("Invalid Input for Age!");
        }
        
        
       
        //for Height 
        if (_Height >1 &&  _Height < 200)
        {
        Height = _Height;
         }
         else 
         {
             Height = 150.0;
             System.out.println("Invalid Input for Height");
         }
        FirstName = _FirstName;
        LastName = _LastName;
 
    }
    /**
     * Method of behaviour.
     * 
     */
    public void  AlwaysSmile()
    {
        System.out.print("Always Smile");
    }

    }
