/**
 * Class to model a Person
 * 
 * @author Gary Tong
 * @version 1.0
 */
public class Person
{
    private String firstName;
    private String lastName;
    private int age;
    private double height;
    
    /**
     * Constructor for creating a Person instace.
     * 
     * @param _firstName    The first name of our Person
     * @param _lastName     The last name of our Person
     * @param _age          The age of our Person
     * @param _height       The height of our Person
     */
    public Person(String _firstName, String _lastName, int _age, double _height)
    {
        firstName = _firstName;
        lastName = _lastName;
        
        if(_age > 0 && _age <= 100)
        {
            age = _age;
        }
        else
        {
            age = 1;
        }

        if(_height > 0 && _height <= 200)
        {
            height = _height;
        }
        else
        {
            height = 150.0;
        }
    }
}

