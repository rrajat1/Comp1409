/**
 * Class to model a Playground
 *
 * Lab 5 Solution
 *
 * @author Gary Tong
 * @version 1.0
 */
public class Playground
{
    public static final int MAX_AGE = 65;

    /**
     * Simple method demonstrating external method calls through object references.
     */
    public void run()
    {
        Person p = new Person();

        System.out.println(p.getFirstName());
        System.out.println(p.getLastName());
        System.out.println(p.getAge());
        System.out.println(p.getHeight());

        p.setFirstName("Gary");
        p.setLastName("Tong");
        p.setAge(31);
        p.setHeight(175.0);

        System.out.println(p.getFirstName());
        System.out.println(p.getLastName());
        System.out.println(p.getAge());
        System.out.println(p.getHeight());

        if(p.getAge() > MAX_AGE)
        {
            System.out.println("Person is old!");
        }
        else
        {
            System.out.println("Person is young!");
        }        
        
        Person p2 = new Person();      
        p2.setFirstName("Bob");
        
        if(p.getFirstName().equals(p2.getFirstName()))
        {
            System.out.println("Same name!");
        }
        else
        {
            System.out.println("Different name!");
        }
    }
}
