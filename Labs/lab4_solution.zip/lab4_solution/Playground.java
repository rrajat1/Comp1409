public class Playground 

{

public void run()

{
Person person1 = new Person();

System.out.println(person1.getFirstName());
System.out.println(person1.getLastName());
System.out.println(person1.getAge());
System.out.println(person1.getHeight());

person1.setFirstName("Fido");
person1.setLastName("Snofu");
person1.setAge(70);
person1.setHeight(170.0);

System.out.println(person1.getFirstName());
System.out.println(person1.getLastName());
System.out.println(person1.getAge());
System.out.println(person1.getHeight());


if (person1.getAge() > 65)
{
System.out.println("Person is old!");
}
else
{
System.out.println("Person is young!");
}
}
}
